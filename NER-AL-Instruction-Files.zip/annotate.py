"""
pipeline/annotate.py — Step 02: GPT-5.1 Annotation
----------------------------------------------------
Annotates chunks via Azure OpenAI GPT-5.1. Dynamic few-shot examples
are retrieved from the FAISS gold index per chunk. Two prompt variants
run per chunk to generate an inter-prompt disagreement signal.

Copilot: implement all TODO blocks. Key points:
- Two prompt variants differ ONLY in how the structured data exclusion
  rule is phrased (see VARIANT_EXCLUSIONS below). Same few-shot examples,
  same negative examples, same output format.
- Always request logprobs=True and top_logprobs=5 for span-level confidence.
- Parse JSON response carefully — GPT-5.1 may return malformed JSON on
  complex notes. Implement robust parsing with fallback.
- All calls are async-compatible but can be run sync for initial implementation.
"""

from __future__ import annotations
import json
import logging
from openai import AzureOpenAI
from models import Chunk, Entity, AnnotatedChunk, MimicGoldExample
from config import AnnotationConfig, AzureSettings
from pipeline.retrieval import retrieve_few_shot_examples

logger = logging.getLogger(__name__)

# Variant 1: mechanistic two-condition framing
# Variant 2: different phrasing of same exclusion — generates disagreement signal
VARIANT_EXCLUSIONS = {
    1: (
        "Does NOT resolve to a medication in RxNorm and is not a laboratory "
        "test, value, or panel. Both conditions must be satisfied."
    ),
    2: (
        "Is not a medication (prescription, OTC, supplement, chemotherapy agent, "
        "contrast agent, or anesthetic) and is not a lab result or diagnostic "
        "measurement. Structured data covers all medications and labs."
    ),
}

HARD_NEGATIVES = """
NEGATIVE EXAMPLES — do not label these as PROCEDURE_TREATMENT:
- "started on metformin 500mg" → [] (medication)
- "WBC 4.5 k/uL" → [] (lab value in structured data)
- "lisinopril 10mg daily for hypertension" → [] (medication)
- "cisplatin-based chemotherapy was initiated" → [] (medication)
- "creatinine 1.8 mg/dL" → [] (lab value)
"""

SYSTEM_PROMPT = """You are a clinical NER system for VA clinical notes.
Extract named entities and return them as a JSON array.
Return ONLY valid JSON. No explanation, no markdown, no preamble."""


def build_prompt(
    chunk_text: str,
    few_shot_examples: list[MimicGoldExample],
    entity_classes: list[str],
    variant: int,
) -> str:
    """
    Build a full annotation prompt for a given variant.

    Args:
        chunk_text: the note chunk to annotate
        few_shot_examples: dynamically retrieved MIMIC gold examples
        entity_classes: list of entity class names for this schema
        variant: 1 or 2 — controls which exclusion phrasing is used

    Returns:
        full prompt string ready for the user message role
    """
    # TODO: implement prompt construction
    # Structure:
    # 1. Schema definition with entity classes
    # 2. Two-condition rule for PROCEDURE_TREATMENT with VARIANT_EXCLUSIONS[variant]
    # 3. HARD_NEGATIVES block
    # 4. Few-shot examples formatted as Text: / Entities: pairs
    # 5. Annotation request for chunk_text
    # 6. Output format instruction: JSON array of {text, label, start, end}
    raise NotImplementedError


def parse_gpt_response(response_text: str) -> list[Entity]:
    """
    Parse GPT-5.1 JSON response into a list of Entity objects.
    Handle malformed JSON gracefully — log and return empty list on failure.

    Args:
        response_text: raw GPT response string

    Returns:
        list of Entity objects (may be empty if parsing fails)
    """
    # TODO: implement robust JSON parsing
    # Strip markdown code fences if present
    # Parse JSON array
    # Validate each item has text, label, start, end fields
    # Build Entity objects with confidence from logprobs if available
    raise NotImplementedError


def extract_span_confidence(logprobs_data: dict, span_tokens: list[str]) -> float:
    """
    Derive a confidence score for an entity span from GPT-5.1 logprob output.
    Average the max token probability over the span tokens.

    Args:
        logprobs_data: logprobs object from OpenAI response
        span_tokens: list of tokens belonging to this span

    Returns:
        float confidence score in [0, 1]
    """
    # TODO: implement logprob extraction
    # Sum log probabilities for span tokens, exponentiate to get probabilities
    # Return mean probability across span tokens
    raise NotImplementedError


def annotate_chunk(
    chunk: Chunk,
    few_shot_examples: list[MimicGoldExample],
    client: AzureOpenAI,
    config: AnnotationConfig,
    azure_settings: AzureSettings,
    entity_classes: list[str],
) -> AnnotatedChunk:
    """
    Annotate a single chunk with both prompt variants.
    Returns an AnnotatedChunk with gpt_v1_entities and gpt_v2_entities populated.

    Args:
        chunk: the Chunk to annotate
        few_shot_examples: top-k MIMIC gold examples retrieved for this chunk
        client: AzureOpenAI client
        config: AnnotationConfig
        azure_settings: deployment name etc.
        entity_classes: entity class names

    Returns:
        AnnotatedChunk with dual predictions and logprobs
    """
    # TODO: implement
    # 1. Build prompt variants 1 and 2
    # 2. Call GPT-5.1 for each variant (request logprobs)
    # 3. Parse responses into Entity lists
    # 4. Extract confidence from logprobs
    # 5. Return AnnotatedChunk with both prediction sets
    raise NotImplementedError


def annotate_chunks_batch(
    chunks: list[Chunk],
    faiss_index,
    gold_examples: list[MimicGoldExample],
    embedder,
    client: AzureOpenAI,
    config: AnnotationConfig,
    azure_settings: AzureSettings,
    entity_classes: list[str],
) -> list[AnnotatedChunk]:
    """
    Annotate a batch of chunks. Retrieves few-shot examples per chunk
    from FAISS before annotation.

    Args:
        chunks: list of Chunk objects to annotate
        faiss_index: loaded FAISS index
        gold_examples: full list of MimicGoldExample objects (for index lookup)
        embedder: SentenceTransformer model for embedding queries
        client: AzureOpenAI client
        config: AnnotationConfig
        azure_settings: AzureSettings
        entity_classes: entity class names

    Returns:
        list of AnnotatedChunk objects
    """
    annotated = []
    for chunk in chunks:
        examples = retrieve_few_shot_examples(
            chunk.text, faiss_index, gold_examples, embedder, k=config.few_shot_k
        )
        annotated_chunk = annotate_chunk(
            chunk, examples, client, config, azure_settings, entity_classes
        )
        annotated.append(annotated_chunk)
    return annotated
