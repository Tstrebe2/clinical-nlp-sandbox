"""
config.py
---------
All pipeline configuration in one place. Copilot: fill in Azure endpoint
details and file paths. All other defaults are tuned for this pipeline.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from pydantic_settings import BaseSettings


class AzureSettings(BaseSettings):
    """Loaded from environment variables / .env file."""
    azure_openai_endpoint: str
    azure_openai_api_key: str
    azure_openai_api_version: str = "2024-12-01-preview"
    azure_openai_deployment: str = "gpt-5.1"

    class Config:
        env_file = ".env"


@dataclass
class ChunkConfig:
    max_tokens: int = 300
    overlap_tokens: int = 50
    skip_sections: set[str] = field(default_factory=lambda: {
        "review_of_systems",
        "vital_signs_template",
        "allergy_list",
        "medication_list",
        "copy_forward",
        "patient_demographics",
        "header",
        "footer",
    })


@dataclass
class AnnotationConfig:
    few_shot_k: int = 5
    logprobs: bool = True
    top_logprobs: int = 5
    max_tokens: int = 1000
    temperature: float = 0.0


@dataclass
class FilterConfig:
    gazetteer_threshold: int = 85          # rapidfuzz partial_ratio
    lab_clf_threshold: float = 0.85        # lab binary classifier probability
    rxnorm_score_threshold: float = 0.8    # scispacy RxNorm linker score
    lab_unit_patterns: list[str] = field(default_factory=lambda: [
        r"\b(WBC|RBC|Hgb|Hct|MCV|MCHC|MCH|PLT|INR|PT|PTT|BMP|CMP|"
        r"BUN|Cr|Na|K|CO2|Cl|Ca|Mg|Phos|ALT|AST|ALP|LDH|GFR|A1c|"
        r"TSH|T4|T3|PSA|CEA|AFP|CA-125|ESR|CRP|Ferritin|B12|Folate)\b",
        r"\b[\w\s]+\s+[\d.]+\s*"
        r"(mg/dL|mmol/L|k/uL|g/dL|mEq/L|%|U/L|IU/L|ng/mL|pg/mL|"
        r"cells/uL|mIU/mL|nmol/L|umol/L|pmol/L|fL|pg|g/L)\b",
    ])


@dataclass
class ModelConfig:
    gator_model_id: str = "UFNLP/gatortron-base"
    embedder_model_id: str = "microsoft/BiomedNLP-BiomedBERT-large"
    # BIO label scheme — extend for your entity classes
    label2id: dict[str, int] = field(default_factory=lambda: {
        "O": 0,
        "B-PROCEDURE_TREATMENT": 1,
        "I-PROCEDURE_TREATMENT": 2,
        # Add additional entity classes here
    })
    learning_rate: float = 2e-5
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 16
    warmup_ratio: float = 0.1
    weight_decay: float = 0.01


@dataclass
class ALConfig:
    seed_va_batch_size: int = 250           # initial GPT VA annotation batch
    al_batch_size: int = 75                 # chunks selected per AL iteration
    max_iterations: int = 20
    uncertainty_alpha: float = 0.4          # weight of uncertainty vs disagreement
    model_disagree_weight: float = 0.6      # cross-model disagreement sub-weight
    prompt_disagree_weight: float = 0.4     # inter-prompt disagreement sub-weight
    proc_treat_class_weight: float = 2.0    # PROCEDURE_TREATMENT oversampling
    persistent_disagreement_threshold: int = 3  # iterations before human flag
    mimic_held_out_size: int = 60           # fixed eval slice


@dataclass
class PathConfig:
    data_dir: Path = Path("data")
    mimic_gold_path: Path = Path("data/mimic_gold.jsonl")
    va_notes_path: Path = Path("data/va_notes.jsonl")
    va_lab_terms_path: Path = Path("data/va_lab_terms.txt")
    faiss_index_path: Path = Path("artifacts/faiss.index")
    faiss_metadata_path: Path = Path("artifacts/faiss_metadata.jsonl")
    model_checkpoint_dir: Path = Path("artifacts/checkpoints")
    mlflow_tracking_uri: str = "mlflow_runs"
    filter_audit_log: Path = Path("logs/filter_audit.jsonl")
    disagreement_log: Path = Path("logs/disagreement_history.jsonl")
    label_studio_url: str = "http://localhost:8080"


@dataclass
class PipelineConfig:
    azure: AzureSettings = field(default_factory=AzureSettings)
    chunk: ChunkConfig = field(default_factory=ChunkConfig)
    annotation: AnnotationConfig = field(default_factory=AnnotationConfig)
    filter: FilterConfig = field(default_factory=FilterConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    al: ALConfig = field(default_factory=ALConfig)
    paths: PathConfig = field(default_factory=PathConfig)
