"""
pipeline/resolve.py — Step 07: Corrective Re-annotation + Conflict Resolution
------------------------------------------------------------------------------
Handles two cases for selected high-uncertainty chunks:

Case A — RxNorm confirms medication + GatorTron disagrees with GPT:
    Trust GatorTron. No GPT call needed. Log as resolved.

Case B — Genuine uncertainty (no clear ontology signal):
    Send to GPT-5.1 with enriched corrective prompt including:
    - Original chunk text
    - Both GPT variant predictions
    - GatorTron prediction
    - RxNorm and VA gazetteer lookup results per disputed span
    - Chain-of-thought instruction

Also tracks persistent disagreements across iterations. Spans that remain
unresolved after config.persistent_disagreement_threshold iterations are
flagged for the final human review pass.

Copilot: implement all TODO blocks.
"""

from __future__ import annotations
import json
import logging
from pathlib import Path
from openai import AzureOpenAI

from models import AnnotatedChunk, Entity, DisagreementRecord
from config import ALConfig, FilterConfig, AzureSettings
from pipeline.filter import (
    is_rxnorm_entity,
    is_lab_entity,
    filter_entities,
)
import spacy

logger = logging.getLogger(__name__)


CORRECTIVE_SYSTEM_PROMPT = """You are a clinical NER system for VA clinical notes.
You are reviewing a prior annotation that disagreed with a discriminative model.
Reason step by step about each disputed span, then return your corrected annotation.
Return ONLY valid JSON. No explanation outside the reasoning block."""


def build_corrective_prompt(
    annotated_chunk: AnnotatedChunk,
    disputed_records: list[DisagreementRecord],
) -> str:
    """
    Build the corrective re-annotation prompt for Case B chunks.
    Includes full disagreement context and chain-of-thought instruction.

    Args:
        annotated_chunk: the chunk with all prediction history
        disputed_records: disagreement records for this chunk's disputed spans

    Returns:
        full prompt string for user message role
    """
    # TODO: implement
    # Structure:
    # 1. Original chunk text
    # 2. Your previous annotations (variant 1 and variant 2)
    # 3. Discriminative model prediction (GatorTron)
    # 4. Ontology lookup results per disputed span (RxNorm, gazetteer)
    # 5. Instruction: reason step by step in a <reasoning> block, then return
    #    corrected annotation JSON
    raise NotImplementedError


def resolve_rxnorm_conflict(
    gpt_label: str,
    gator_label: str,
    span_text: str,
    nlp: spacy.Language,
    rxnorm_threshold: float = 0.8,
) -> tuple[str, bool]:
    """
    Case A resolution: if GPT predicted PROCEDURE_TREATMENT, GatorTron
    predicted otherwise, and RxNorm confirms medication — trust GatorTron.

    Args:
        gpt_label: GPT-5.1 variant 1 predicted label
        gator_label: GatorTron predicted label
        span_text: the entity span text
        nlp: scispacy pipeline with RxNorm linker
        rxnorm_threshold: minimum RxNorm linker score

    Returns:
        (resolved_label: str, was_resolved: bool)
    """
    if (
        gpt_label == "PROCEDURE_TREATMENT"
        and gator_label != "PROCEDURE_TREATMENT"
        and is_rxnorm_entity(span_text, nlp, rxnorm_threshold)
    ):
        return gator_label, True
    return gpt_label, False


def update_disagreement_history(
    annotated_chunk: AnnotatedChunk,
    disagreement_log_path: Path,
    persistent_threshold: int,
) -> list[DisagreementRecord]:
    """
    Update the disagreement history for a chunk after a corrective annotation pass.
    Increment iteration_count for existing records, create new records for new disputes.
    Flag spans that exceed the persistent_threshold for human review.

    Args:
        annotated_chunk: chunk with current prediction sets
        disagreement_log_path: path to JSONL disagreement log
        persistent_threshold: iterations before flagging for human review

    Returns:
        list of DisagreementRecord objects for disputed spans in this chunk
    """
    # TODO: implement
    # 1. Find spans where GatorTron and GPT still disagree after correction
    # 2. Check existing records in disagreement_log for this chunk_id
    # 3. Increment iteration_count or create new record
    # 4. Set flagged_for_human_review=True if iteration_count >= persistent_threshold
    # 5. Write updated records back to log
    raise NotImplementedError


def corrective_reannotate_chunk(
    annotated_chunk: AnnotatedChunk,
    client: AzureOpenAI,
    azure_settings: AzureSettings,
    nlp: spacy.Language,
    va_lab_terms: list[str],
    lab_clf,
    filter_config: FilterConfig,
    al_config: ALConfig,
    disagreement_log_path: Path,
    audit_log_path: Path | None = None,
) -> AnnotatedChunk:
    """
    Apply corrective re-annotation to a single selected chunk.
    Handles Case A (RxNorm resolution) and Case B (GPT corrective prompt).
    Applies per-entity filter inline after corrective annotation.
    Updates persistent disagreement tracking.

    Args:
        annotated_chunk: chunk selected by AL query strategy
        client: AzureOpenAI client
        azure_settings: deployment settings
        nlp: scispacy pipeline
        va_lab_terms: VA lab gazetteer terms
        lab_clf: fitted lab classifier
        filter_config: FilterConfig
        al_config: ALConfig
        disagreement_log_path: path to disagreement JSONL log
        audit_log_path: path to filter audit JSONL log

    Returns:
        AnnotatedChunk with corrective_annotation_applied=True and
        filtered_entities updated
    """
    # TODO: implement full Case A + Case B logic
    # 1. For each disputed span: try Case A (RxNorm resolution)
    # 2. If Case A resolves: apply GatorTron label, log as resolved
    # 3. If Case B needed: build corrective prompt, call GPT-5.1
    # 4. Parse corrective response, apply step 03 filter inline
    # 5. Update disagreement history
    # 6. Set annotated_chunk.corrective_annotation_applied = True
    raise NotImplementedError


def corrective_reannotate_batch(
    selected_chunks: list[AnnotatedChunk],
    client: AzureOpenAI,
    azure_settings: AzureSettings,
    nlp: spacy.Language,
    va_lab_terms: list[str],
    lab_clf,
    filter_config: FilterConfig,
    al_config: ALConfig,
    disagreement_log_path: Path,
    audit_log_path: Path | None = None,
) -> tuple[list[AnnotatedChunk], list[DisagreementRecord]]:
    """
    Apply corrective re-annotation to all chunks in the AL query batch.

    Returns:
        (corrected_chunks, all_persistent_disagreement_records)
    """
    corrected = []
    persistent = []

    for chunk in selected_chunks:
        corrected_chunk = corrective_reannotate_chunk(
            chunk, client, azure_settings, nlp,
            va_lab_terms, lab_clf, filter_config, al_config,
            disagreement_log_path, audit_log_path,
        )
        corrected.append(corrected_chunk)

        # Collect spans flagged for human review
        persistent.extend([
            r for r in corrected_chunk.disagreement_records
            if r.flagged_for_human_review
        ])

    return corrected, persistent
