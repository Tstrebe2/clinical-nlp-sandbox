"""
run_pipeline.py — Main Orchestration Entry Point
-------------------------------------------------
Runs the full VA Clinical NER active learning pipeline end-to-end.

Usage:
    python run_pipeline.py [--phase {all,phase1,al_loop,review}]
                           [--al-iterations N]
                           [--resume-from-iteration N]

Phases:
    phase1      Initial VA annotation pass (runs once)
    al_loop     AL loop only (requires phase1 to have run)
    review      Final human review + retrain (requires al_loop to have run)
    all         Run everything sequentially (default)

Copilot: implement all TODO blocks. The orchestration logic should call
the pipeline modules in order, passing state between phases. Use the
config dataclasses throughout — do not hardcode constants.
"""

from __future__ import annotations
import argparse
import json
import logging
from pathlib import Path

from config import PipelineConfig, AzureSettings
from models import AnnotatedChunk, MimicGoldExample, DisagreementRecord
from pipeline.chunk import process_note_sections
from pipeline.annotate import annotate_chunks_batch
from pipeline.filter import (
    load_rxnorm_nlp,
    load_va_lab_terms,
    apply_filter_to_annotated_chunk,
)
from pipeline.retrieval import (
    load_faiss_index,
    retrieve_few_shot_examples,
    add_reviewed_examples_to_index,
)
from pipeline.train import train_or_retrain
from pipeline.score import score_unlabeled_pool
from pipeline.query import select_query_batch
from pipeline.resolve import corrective_reannotate_batch
from pipeline.review import push_to_label_studio, export_reviewed_labels
from openai import AzureOpenAI
import mlflow

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


def load_mimic_gold(path: Path) -> list[MimicGoldExample]:
    """Load 300 MIMIC gold examples from JSONL."""
    # TODO: implement — parse JSONL, return list of MimicGoldExample
    raise NotImplementedError


def load_va_notes(path: Path) -> list[dict]:
    """Load VA clinical notes from JSONL. Each record has note_id + sections."""
    # TODO: implement
    raise NotImplementedError


def load_lab_classifier(path: Path):
    """Load fitted lab binary classifier (joblib)."""
    # TODO: implement with joblib.load
    raise NotImplementedError


def save_pool_state(pool: list[AnnotatedChunk], path: Path) -> None:
    """Serialize annotated chunk pool to disk between iterations."""
    # TODO: implement — serialize to JSONL using dataclasses.asdict
    raise NotImplementedError


def load_pool_state(path: Path) -> list[AnnotatedChunk]:
    """Load annotated chunk pool from disk."""
    # TODO: implement
    raise NotImplementedError


def run_phase1(config: PipelineConfig) -> list[AnnotatedChunk]:
    """
    Phase 1: Initial VA annotation pass.

    Steps:
    1. Load all VA notes, section-chunk them (step 01)
    2. Sample seed_va_batch_size chunks randomly for initial annotation
    3. Annotate seed batch with GPT-5.1 + FAISS few-shot (step 02)
    4. Apply per-entity filter to all annotations (step 03)
    5. Save annotated pool state to disk

    Returns:
        list of all AnnotatedChunk objects (seed batch annotated, rest unlabeled)
    """
    logger.info("=== Phase 1: Initial VA annotation pass ===")
    # TODO: implement
    raise NotImplementedError


def run_al_loop(
    config: PipelineConfig,
    initial_pool: list[AnnotatedChunk],
    mimic_gold: list[MimicGoldExample],
    max_iterations: int | None = None,
) -> tuple[list[AnnotatedChunk], list[DisagreementRecord]]:
    """
    Phase 2: AL loop.

    Each iteration:
    1. Retrain GatorTron on accumulated labeled set (step 04)
    2. Score unlabeled pool (step 05)
    3. Select top-k by query score (step 06)
    4. Corrective re-annotation of selected chunks (step 07)
    5. Apply per-entity filter inline
    6. Update persistent disagreement tracking
    7. Move selected chunks from unlabeled to labeled pool

    Convergence check: stop if overall F1 on MIMIC held-out does not
    improve by >= 0.005 for 3 consecutive iterations.

    Args:
        config: PipelineConfig
        initial_pool: output from run_phase1
        mimic_gold: all 300 MIMIC gold examples
        max_iterations: override config.al.max_iterations if provided

    Returns:
        (final_pool, all_persistent_disagreement_records)
    """
    logger.info("=== Phase 2: AL loop ===")
    # TODO: implement full loop with convergence check and state persistence
    # Use mlflow.start_run() with nested=True for each iteration
    raise NotImplementedError


def run_final_review(
    config: PipelineConfig,
    final_pool: list[AnnotatedChunk],
    persistent_disagreements: list[DisagreementRecord],
    mimic_gold: list[MimicGoldExample],
    faiss_index,
    gold_examples: list[MimicGoldExample],
    embedder,
) -> None:
    """
    Phase 3: Final human review + retrain.

    Steps:
    1. Push persistently disagreed chunks to Label Studio (step 08)
    2. Wait for human review completion (poll Label Studio SDK)
    3. Export reviewed labels
    4. Add reviewed VA spans to FAISS index
    5. Final GatorTron retrain on full labeled set with gold corrections (step 09)
    6. Evaluate on MIMIC held-out + VA test set
    7. Log final metrics to MLflow

    Args:
        config: PipelineConfig
        final_pool: all AnnotatedChunk objects from AL loop
        persistent_disagreements: spans flagged for human review
        mimic_gold: all 300 MIMIC gold examples
        faiss_index: current FAISS index (will be enriched)
        gold_examples: current gold example list
        embedder: SentenceTransformer embedder
    """
    logger.info("=== Phase 3: Final human review + retrain ===")
    # TODO: implement
    raise NotImplementedError


def main() -> None:
    parser = argparse.ArgumentParser(description="VA Clinical NER AL Pipeline")
    parser.add_argument(
        "--phase",
        choices=["all", "phase1", "al_loop", "review"],
        default="all",
    )
    parser.add_argument("--al-iterations", type=int, default=None)
    parser.add_argument("--resume-from-iteration", type=int, default=0)
    args = parser.parse_args()

    config = PipelineConfig()
    config.paths.model_checkpoint_dir.mkdir(parents=True, exist_ok=True)
    config.paths.data_dir.mkdir(parents=True, exist_ok=True)
    Path("logs").mkdir(exist_ok=True)
    Path("artifacts").mkdir(exist_ok=True)

    mlflow.set_tracking_uri(config.paths.mlflow_tracking_uri)
    mlflow.set_experiment("va_clinical_ner_al")

    mimic_gold = load_mimic_gold(config.paths.mimic_gold_path)
    faiss_index, gold_examples = load_faiss_index(
        config.paths.faiss_index_path,
        config.paths.faiss_metadata_path,
    )

    if args.phase in ("all", "phase1"):
        pool = run_phase1(config)
        save_pool_state(pool, config.paths.data_dir / "pool_phase1.jsonl")

    if args.phase in ("all", "al_loop"):
        if args.phase == "al_loop":
            pool = load_pool_state(config.paths.data_dir / "pool_phase1.jsonl")
        final_pool, persistent = run_al_loop(
            config, pool, mimic_gold, args.al_iterations
        )
        save_pool_state(final_pool, config.paths.data_dir / "pool_final.jsonl")

    if args.phase in ("all", "review"):
        if args.phase == "review":
            final_pool = load_pool_state(config.paths.data_dir / "pool_final.jsonl")
            persistent = [
                DisagreementRecord(**r)
                for r in json.loads(
                    (config.paths.data_dir / "persistent_disagreements.jsonl").read_text()
                )
            ]
        from pipeline.retrieval import load_embedder
        embedder = load_embedder(config.model.embedder_model_id)
        run_final_review(
            config, final_pool, persistent, mimic_gold,
            faiss_index, gold_examples, embedder,
        )


if __name__ == "__main__":
    main()
