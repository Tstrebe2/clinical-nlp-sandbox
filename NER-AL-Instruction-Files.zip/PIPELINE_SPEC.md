# VA Clinical NER — Active Learning Pipeline Specification

## Overview

Sequential active learning pipeline for clinical named entity recognition (NER)
on VA clinical notes. Uses GatorTron as the discriminative token classifier and
GPT-5.1 (secure Azure OpenAI VA-compliant endpoint) as the bulk annotator and
corrective re-annotator. No human-in-the-loop during the AL loop itself; human
review occurs once after convergence, targeted at persistently uncertain spans only.

---

## Pre-requisites (built once, updated as needed)

### 1. VA Structured Data Filter Vocabulary

Built from VA structured lab and medication sources. Used inline after every
annotation pass to exclude entities that exist in structured data.

Components:
- `va_lab_terms`: list of unique lab test names extracted from VA structured lab
  data. Normalized to lowercase. Used for fuzzy matching.
- `rxnorm_linker`: scispacy pipeline with `en_core_sci_lg` + RxNorm entity linker.
  Used to resolve predicted spans to RxNorm for medication exclusion.
- `lab_clf`: lightweight binary classifier (TF-IDF char n-gram + logistic
  regression) trained on span text. Fallback layer for lab detection.

See: `setup/build_gazetteer.py`, `setup/train_lab_classifier.py`

### 2. MIMIC Gold Index + GatorTron Seed

300 hand-labeled MIMIC examples (clean, schema-compliant, no medications labeled
under PROCEDURE_TREATMENT despite MIMIC data containing them).

Built products:
- `faiss_index`: FAISS IndexFlatIP built from BiomedBERT
  (`microsoft/BiomedNLP-BiomedBERT-large`) embeddings of each gold example.
  Used for dynamic few-shot retrieval at annotation time.
- `GatorTron v1`: initial fine-tune of `UFNLP/gatortron-base` on the 300 MIMIC
  gold examples. This is the seed model before any VA data is seen.

See: `setup/build_faiss.py`, `setup/seed_train.py`

---

## Pipeline Architecture

### Phase 1: Initial VA Annotation (runs once)

```
VA clinical notes
    → 01: Section detection + chunking
    → 02: GPT-5.1 seed annotation (dynamic few-shot, dual prompts, logprobs)
    → 03: Per-entity structured data filter  [loops per entity]
    → filtered seed labels
```

Annotate a random seed batch of ~200-300 VA chunks with GPT-5.1 to bootstrap
the first VA-domain GatorTron retrain. All remaining chunks enter the unlabeled
pool for the AL loop.

### Phase 2: AL Loop (repeats ~10-20 iterations, 50-100 chunks per batch)

```
    → 04: GatorTron retrain  (MIMIC gold + accumulated filtered + resolved labels)
    → 05: Score unlabeled pool  (GatorTron token-level uncertainty)
    → 06: AL query strategy  (uncertainty + disagreement + class weighting)
    → 07: GPT-5.1 corrective re-annotation  (disagreement context + CoT + ontology)
         → 03: per-entity filter applied inline
         → persistent disagreement tracking (flag if 3+ iterations unresolved)
    → back to 04
```

Loop until F1 plateaus on held-out MIMIC slice (typically 10-20 iterations).

### Phase 3: Final Human Review (runs once, post-convergence)

```
    → 08: Human review (Label Studio)
         — targeted: persistently disagreed spans only
         — full disagreement context + ontology results shown
    → 09: Final GatorTron retrain + evaluate
```

---

## Step Specifications

### Step 01: Section Detection + Chunking

**Input:** raw VA clinical note text
**Output:** list of `Chunk` objects (text, section_type, note_id, chunk_id)

Logic:
1. Run section detector to identify section types (A/P, HPI, medications,
   interval history, procedure notes, ROS, etc.)
2. Skip sections in `SKIP_SECTIONS` set (ROS templates, boilerplate, copy-forward)
3. For each retained section:
   - If `len(tokenizer.encode(section_text)) <= MAX_TOKENS (300)`: keep as-is
   - Else: apply sliding window chunker with `overlap=50` tokens
4. All output chunks enter the unlabeled pool

**Key constants:**
- `MAX_TOKENS = 300`
- `OVERLAP_TOKENS = 50`
- `SKIP_SECTIONS = {"review_of_systems", "vital_signs_template", "allergy_list",
                    "medication_list", "copy_forward"}`

Note: section detection is already implemented externally. This module receives
section-chunked output and applies the token-length guard + sliding window.

---

### Step 02: GPT-5.1 Annotation

**Input:** list of `Chunk` objects
**Output:** list of `AnnotatedChunk` objects with dual predictions and logprobs

Logic:
1. For each chunk, retrieve top-5 most similar MIMIC gold examples from FAISS
   using BiomedBERT embeddings (cosine similarity).
2. Build two prompt variants (variant 1 and variant 2) that differ in how
   they phrase the structured data exclusion rule. Both use the same few-shot
   examples and hard negative examples.
3. Call GPT-5.1 endpoint twice per chunk (once per variant). Request logprobs.
4. Extract span-level confidence from logprobs for each prediction.
5. Store both predictions + logprobs on the chunk for downstream use.

**Prompt structure:**
```
System: You are a clinical NER system for VA clinical notes.

PROCEDURE_TREATMENT must satisfy BOTH conditions:
1. Describes a clinical action, intervention, or procedure performed on/for patient
2. [VARIANT-SPECIFIC exclusion phrasing — see annotate.py]

NEGATIVE EXAMPLE (do not label medications as procedures):
Text: "Patient was started on metformin 500mg for glycemic control"
WRONG: [metformin 500mg | PROCEDURE_TREATMENT]
CORRECT: [] — this is a medication, excluded by structured data

[5 dynamically retrieved MIMIC gold few-shot examples]

Annotate the following note section:
[chunk text]

Return JSON array: [{"text": ..., "label": ..., "start": int, "end": int}]
```

**Variant 2 differs only in the exclusion condition phrasing** — same structure,
different words. This gives inter-prompt disagreement as a cheap QBC signal.

---

### Step 03: Per-Entity Structured Data Filter

**Input:** list of predicted entities from a single chunk
**Output:** same list with `filtered: bool` and `filter_reason: str` fields added;
           return only non-filtered entities for downstream use

**Runs per entity in a loop after every annotation call (steps 02 and 07).**

Filter cascade (short-circuit on first match):

**Medication filter:**
- Run scispacy RxNorm linker on span text
- If any linked entity maps to a RxNorm concept: `filtered=True, reason="rxnorm"`

**Lab filter (three layers, short-circuit):**
- Layer 1 — Unit pattern regex: match `\b\w+\s*[\d.]+\s*(mg/dL|mmol/L|k/uL|g/dL|
  mEq/L|%|U/L|IU/L|ng/mL|pg/mL|cells/uL)\b` and common standalone lab
  abbreviations (WBC, RBC, Hgb, Hct, BMP, CMP, INR, PT, PTT, etc.)
  → highest precision, use threshold=1.0
- Layer 2 — VA gazetteer fuzzy match: `rapidfuzz.process.extractOne` with
  `fuzz.partial_ratio`, threshold ≥ 85 against `va_lab_terms`
- Layer 3 — Lab binary classifier: `lab_clf.predict_proba([span_text])[0][1] > 0.85`

**Logging:** all filtered spans are logged with reason to a filter audit log.
Do not silently drop — the audit log is used to monitor GPT-5.1 error drift
across AL iterations.

---

### Step 04: GatorTron Train / Retrain

**Input:** accumulated labeled dataset (MIMIC gold + filtered VA labels +
           conflict-resolved labels from all previous AL iterations)
**Output:** updated GatorTron checkpoint

**Initial run:** fine-tune from `UFNLP/gatortron-base` on 300 MIMIC gold examples.
**Subsequent runs:** fine-tune from previous checkpoint on cumulative labeled set.

Before retraining (iterations 2+): apply label conflict resolution:
- For each VA label where GPT-5.1 predicted `PROCEDURE_TREATMENT` and GatorTron
  predicted something else: check if span resolves to RxNorm.
- If RxNorm confirms medication: use GatorTron's prediction (it is correct).
- Otherwise: keep GPT-5.1 label.

**Training config:**
- Model: `UFNLP/gatortron-base` (or medium if compute allows)
- Tagging scheme: BIO per entity class
- Evaluation: seqeval F1 per class on held-out MIMIC slice (fixed, ~60 examples)
- Logging: MLflow — per-class F1, overall F1, AL iteration number

---

### Step 05: Score Unlabeled Pool

**Input:** unlabeled chunk pool, current GatorTron checkpoint
**Output:** pool with `uncertainty_score` per chunk

Logic:
1. Run GatorTron inference on all unlabeled chunks (batch inference).
2. For each chunk, extract token-level softmax probabilities.
3. Compute least confidence per span: `1 - max(probs, axis=-1)` averaged over
   span tokens.
4. Store per-chunk uncertainty scores for query strategy.

Pool management via `small-text` `PoolBasedActiveLearner`. Tracks which chunks
are labeled vs unlabeled across iterations.

---

### Step 06: AL Query Strategy

**Input:** scored unlabeled pool with GatorTron uncertainty + GPT-5.1 dual
           predictions from initial annotation pass (or prior iteration)
**Output:** top-k chunks selected for corrective re-annotation

**Joint query score:**
```python
score = class_weight * (
    alpha * uncertainty +
    (1 - alpha) * (0.6 * model_disagree + 0.4 * prompt_disagree)
)
```

Where:
- `uncertainty` = GatorTron token-level least confidence (averaged per chunk)
- `model_disagree` = int(GatorTron pred != GPT v1 label) — cross-model QBC
- `prompt_disagree` = int(GPT v1 label != GPT v2 label) — inter-prompt QBC
- `class_weight` = 2.0 if any predicted entity is `PROCEDURE_TREATMENT` else 1.0
- `alpha` = 0.4 (tune empirically)

Select top-k by score. Recommended k=50-100 per iteration.

---

### Step 07: GPT-5.1 Corrective Re-annotation

**Input:** top-k selected chunks with full disagreement context
**Output:** corrected annotations with per-entity filter applied inline;
           persistent disagreement flags updated

For each selected chunk, determine re-annotation strategy:

**Case A — RxNorm confirms medication + GatorTron disagrees with GPT:**
Use GatorTron's prediction directly. No GPT call needed. Log as resolved.

**Case B — Genuine uncertainty (no ontology signal, persistent disagreement):**
Send to GPT-5.1 with enriched corrective prompt including:
- Original chunk text
- GPT-5.1 original annotation (both variants)
- GatorTron prediction
- RxNorm lookup result for each disputed span
- VA gazetteer lookup result for each disputed span
- Inter-prompt disagreement flag
- Chain-of-thought instruction: reason step by step before annotating

```
You previously annotated this text and your annotation disagreed with
our discriminative model. Please reconsider.

Text: {chunk_text}

Your previous annotations:
  Variant 1: {gpt_v1_labels}
  Variant 2: {gpt_v2_labels}

GatorTron prediction: {gator_preds}

Ontology lookups for disputed spans:
  "{span_text}": RxNorm={rxnorm_result}, VA lab match={gazetteer_result}

Reason step by step about each disputed span, then return your
corrected annotation as JSON.
```

**Persistent disagreement tracking:**
After each corrective re-annotation, check if GatorTron and GPT-5.1 still
disagree on any span. If a span has been disputed for >= 3 AL iterations
without resolution: flag it for final human review. Store in
`persistent_disagreements` list.

Apply step 03 filter inline after corrective annotation before storing labels.

---

### Step 08: Final Human Review

**Input:** `persistent_disagreements` list (spans flagged across >= 3 iterations)
**Output:** gold-corrected labels for all flagged spans

Interface: Label Studio with Label Studio SDK for programmatic task management.

Each task shown to human reviewer includes:
- Note chunk text
- All disagreement history (GPT variants, GatorTron predictions, per iteration)
- Ontology lookup results (RxNorm, gazetteer)
- GatorTron pre-annotation shown as suggestion

Human reviewer adjudicates only genuinely ambiguous cases.
Reviewed labels are authoritative and override all model predictions.

Reviewed spans are also added to the FAISS gold index to enrich few-shot
retrieval for any future pipeline runs.

---

### Step 09: Final GatorTron Retrain + Evaluate

**Input:** all accumulated labels + human-reviewed gold corrections
**Output:** final GatorTron checkpoint

Retrain on full labeled set with human-reviewed labels replacing any prior
prediction for flagged spans.

Evaluate on:
- Fixed held-out MIMIC slice: benchmark comparability across iterations
- VA held-out test set: operational F1 per entity class

Log final per-class F1 to MLflow.

---

## Data Models

See `models.py` for all dataclasses.

Key types:
- `Chunk`: text, section_type, note_id, chunk_id, token_count
- `Entity`: text, label, start, end, filtered, filter_reason, confidence
- `AnnotatedChunk`: chunk + gpt_v1_entities + gpt_v2_entities + gator_entities +
                    uncertainty_score + query_score + disagreement_history
- `DisagreementRecord`: chunk_id, span_text, span_start, span_end,
                         gpt_v1_label, gpt_v2_label, gator_label,
                         rxnorm_result, gazetteer_result, iteration_count

---

## Configuration

All constants in `config.py` as dataclasses. Key values:

| Parameter | Value | Notes |
|---|---|---|
| MAX_TOKENS | 300 | Sliding window threshold |
| OVERLAP_TOKENS | 50 | Sliding window overlap |
| FEW_SHOT_K | 5 | MIMIC examples per annotation call |
| AL_BATCH_SIZE | 50-100 | Chunks selected per iteration |
| UNCERTAINTY_ALPHA | 0.4 | Weight of uncertainty vs disagreement |
| CLASS_WEIGHT_PROC | 2.0 | PROCEDURE_TREATMENT oversampling |
| GAZETTEER_THRESHOLD | 85 | rapidfuzz partial_ratio threshold |
| LAB_CLF_THRESHOLD | 0.85 | Lab classifier probability threshold |
| PERSISTENT_ITER | 3 | Iterations before flagging for human review |
| SEED_VA_BATCH | 200-300 | Initial GPT-5.1 VA annotation batch size |
| MIMIC_HELD_OUT | 60 | Fixed held-out MIMIC eval examples |
| GPT_MODEL | gpt-5.1 | Azure OpenAI deployment name |
| GATOR_MODEL | UFNLP/gatortron-base | HuggingFace model ID |
| EMBEDDER_MODEL | microsoft/BiomedNLP-BiomedBERT-large | Few-shot embedder |

---

## Stack

| Layer | Library | Purpose |
|---|---|---|
| LLM annotation | `openai` (Azure) | GPT-5.1 annotation + corrective re-annotation |
| Token classifier | `transformers`, `torch` | GatorTron fine-tuning + inference |
| AL orchestration | `small-text` | Pool management across iterations |
| Clinical NLP | `scispacy`, `en_core_sci_lg` | RxNorm linking |
| Embeddings | `sentence-transformers` | BiomedBERT few-shot retrieval |
| Vector index | `faiss-cpu` | MIMIC gold index |
| Fuzzy matching | `rapidfuzz` | VA gazetteer matching |
| Experiment tracking | `mlflow` | Per-class F1 per AL iteration |
| Annotation UI | `label-studio-sdk` | Final human review queue |
| Evaluation | `seqeval` | NER F1 scoring |
| Config | `pydantic` | Settings management |

---

## File Structure

```
va_ner_pipeline/
├── PIPELINE_SPEC.md          # this document
├── requirements.txt
├── config.py                 # all configuration dataclasses
├── models.py                 # all data model dataclasses
├── run_pipeline.py           # main orchestration entry point
├── pipeline/
│   ├── __init__.py
│   ├── chunk.py              # step 01: section chunking
│   ├── annotate.py           # step 02: GPT-5.1 annotation
│   ├── filter.py             # step 03: per-entity structured data filter
│   ├── train.py              # step 04: GatorTron train/retrain
│   ├── score.py              # step 05: uncertainty scoring
│   ├── query.py              # step 06: AL query strategy
│   ├── resolve.py            # step 07: corrective re-annotation + conflict resolution
│   └── review.py             # step 08: Label Studio human review interface
└── setup/
    ├── build_gazetteer.py    # build VA lab term list from structured data
    ├── train_lab_classifier.py # train lab binary classifier
    ├── build_faiss.py        # embed MIMIC gold + build FAISS index
    └── seed_train.py         # initial GatorTron fine-tune on MIMIC gold
```
