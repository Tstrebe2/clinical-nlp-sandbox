"""
pipeline/filter.py — Step 03: Per-Entity Structured Data Filter
---------------------------------------------------------------
Loops over each predicted entity and flags medications (RxNorm) and
labs (three-layer cascade). Applied inline after every annotation call
— both the initial pass (step 02) and corrective re-annotation (step 07).

Filter cascade for labs (short-circuits on first match):
  Layer 1: unit pattern regex — highest precision
  Layer 2: VA gazetteer fuzzy match (rapidfuzz)
  Layer 3: lab binary classifier fallback

Filtered spans are flagged and logged. They are NOT silently dropped —
the audit log tracks GPT-5.1 error patterns across AL iterations.

Copilot: implement all TODO blocks.
"""

from __future__ import annotations
import re
import json
import logging
from pathlib import Path
from datetime import datetime
from rapidfuzz import process, fuzz
from sklearn.pipeline import Pipeline as SklearnPipeline
import spacy

from models import Entity, AnnotatedChunk
from config import FilterConfig

logger = logging.getLogger(__name__)


def load_rxnorm_nlp(model: str = "en_core_sci_lg") -> spacy.Language:
    """
    Load scispacy pipeline with RxNorm entity linker.
    Cache the loaded model — do not reload on every call.

    Copilot: use spacy.load with add_pipe("scispacy_linker",
    config={"resolve_abbreviations": True, "linker_name": "rxnorm"})
    """
    # TODO: implement with module-level cache
    raise NotImplementedError


def load_va_lab_terms(terms_path: Path) -> list[str]:
    """
    Load VA lab term list from a plain text file (one term per line).
    Normalize to lowercase. Return as list for rapidfuzz matching.
    """
    # TODO: implement
    raise NotImplementedError


def is_rxnorm_entity(span_text: str, nlp: spacy.Language, threshold: float = 0.8) -> bool:
    """
    Check if a span resolves to a RxNorm concept via scispacy linking.

    Args:
        span_text: the entity span text
        nlp: scispacy pipeline with RxNorm linker
        threshold: minimum linker score to accept as RxNorm match

    Returns:
        True if span links to RxNorm with score >= threshold
    """
    # TODO: run nlp(span_text), check ent._.kb_ents for RXNORM prefix
    raise NotImplementedError


def matches_lab_unit_pattern(span_text: str, patterns: list[str]) -> bool:
    """
    Layer 1: Check if span matches any lab unit pattern (regex).
    Highest precision — catches inline numeric lab results.

    Args:
        span_text: entity span text
        patterns: compiled regex patterns from FilterConfig.lab_unit_patterns

    Returns:
        True if any pattern matches
    """
    # TODO: implement with re.search, case-insensitive
    raise NotImplementedError


def is_va_lab_term(
    span_text: str,
    va_lab_terms: list[str],
    threshold: int = 85,
) -> tuple[bool, str | None]:
    """
    Layer 2: Fuzzy match span against VA lab gazetteer.

    Args:
        span_text: entity span text
        va_lab_terms: list of normalized VA lab term strings
        threshold: rapidfuzz partial_ratio threshold (default 85)

    Returns:
        (matched: bool, matched_term: str | None)
    """
    # TODO: use rapidfuzz.process.extractOne with fuzz.partial_ratio
    raise NotImplementedError


def is_lab_classifier(span_text: str, lab_clf: SklearnPipeline, threshold: float = 0.85) -> bool:
    """
    Layer 3: Fallback lab binary classifier.
    TF-IDF char n-gram + logistic regression trained on labeled spans.

    Args:
        span_text: entity span text
        lab_clf: fitted sklearn Pipeline
        threshold: positive class probability threshold

    Returns:
        True if classifier confidence >= threshold
    """
    # TODO: implement
    raise NotImplementedError


def is_lab_entity(
    span_text: str,
    va_lab_terms: list[str],
    lab_clf: SklearnPipeline,
    config: FilterConfig,
    nlp: spacy.Language,
) -> tuple[bool, str | None]:
    """
    Three-layer lab detection cascade. Short-circuits on first match.

    Returns:
        (is_lab: bool, reason: str | None)
        reason is one of: "unit_pattern", "gazetteer:{term}", "classifier", None
    """
    if matches_lab_unit_pattern(span_text, config.lab_unit_patterns):
        return True, "unit_pattern"

    matched, term = is_va_lab_term(span_text, va_lab_terms, config.gazetteer_threshold)
    if matched:
        return True, f"gazetteer:{term}"

    if is_lab_classifier(span_text, lab_clf, config.lab_clf_threshold):
        return True, "classifier"

    return False, None


def filter_entities(
    entities: list[Entity],
    chunk_text: str,
    va_lab_terms: list[str],
    lab_clf: SklearnPipeline,
    nlp: spacy.Language,
    config: FilterConfig,
    audit_log_path: Path | None = None,
) -> list[Entity]:
    """
    Apply per-entity filter to a list of predicted entities.
    Mutates each Entity in place (sets filtered and filter_reason).
    Logs filtered entities to audit log.

    Args:
        entities: predicted entities from a single chunk
        chunk_text: source chunk text (for audit logging context)
        va_lab_terms: VA lab gazetteer terms
        lab_clf: fitted lab binary classifier
        nlp: scispacy pipeline with RxNorm linker
        config: FilterConfig
        audit_log_path: optional path for audit log JSONL

    Returns:
        list of non-filtered Entity objects (filtered ones kept in input list
        with filtered=True for audit purposes but excluded from return value)
    """
    clean_entities = []
    for entity in entities:
        # Medication check
        if is_rxnorm_entity(entity.text, nlp, config.rxnorm_score_threshold):
            entity.filtered = True
            entity.filter_reason = "rxnorm"
        else:
            # Lab check
            is_lab, reason = is_lab_entity(
                entity.text, va_lab_terms, lab_clf, config, nlp
            )
            if is_lab:
                entity.filtered = True
                entity.filter_reason = reason

        if entity.filtered:
            _log_filtered_entity(entity, chunk_text, audit_log_path)
        else:
            clean_entities.append(entity)

    return clean_entities


def apply_filter_to_annotated_chunk(
    annotated_chunk: AnnotatedChunk,
    va_lab_terms: list[str],
    lab_clf: SklearnPipeline,
    nlp: spacy.Language,
    config: FilterConfig,
    audit_log_path: Path | None = None,
) -> AnnotatedChunk:
    """
    Apply filter to both GPT prediction sets on an AnnotatedChunk.
    Sets annotated_chunk.filtered_entities to the v1 clean predictions
    (v1 is treated as primary). Both v1 and v2 are filtered for
    disagreement scoring purposes.

    Returns:
        the same AnnotatedChunk with filtered_entities populated
    """
    # TODO: implement — filter v1 and v2, store v1 clean in filtered_entities
    raise NotImplementedError


def _log_filtered_entity(entity: Entity, chunk_text: str, audit_log_path: Path | None) -> None:
    """Append a filtered entity record to the audit log JSONL."""
    if audit_log_path is None:
        return
    record = {
        "timestamp": datetime.utcnow().isoformat(),
        "span_text": entity.text,
        "label": entity.label,
        "filter_reason": entity.filter_reason,
        "chunk_snippet": chunk_text[:120],
    }
    with open(audit_log_path, "a") as f:
        f.write(json.dumps(record) + "\n")
