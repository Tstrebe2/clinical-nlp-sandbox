"""
pipeline/chunk.py — Step 01: Section Detection + Chunking
----------------------------------------------------------
Receives section-chunked note output from the external section detector
and applies the token-length guard + sliding window for long sections.

Copilot: implement all TODO blocks. The section detector itself is external
and already implemented — this module receives its output and applies the
token guard and sliding window.
"""

from __future__ import annotations
import uuid
from transformers import AutoTokenizer
from models import Chunk
from config import ChunkConfig


def get_tokenizer(model_id: str = "UFNLP/gatortron-base") -> AutoTokenizer:
    # TODO: load and cache tokenizer
    raise NotImplementedError


def chunk_section(
    section_text: str,
    section_type: str,
    note_id: str,
    config: ChunkConfig,
    tokenizer: AutoTokenizer,
) -> list[Chunk]:
    """
    Apply sliding window chunking to a single section if it exceeds
    config.max_tokens. Otherwise return the section as a single Chunk.

    Sliding window logic:
    - Encode section_text with tokenizer
    - If len(tokens) <= max_tokens: return single Chunk
    - Else: slide a window of max_tokens tokens with overlap_tokens overlap
    - Decode each window back to text
    - Each window becomes a separate Chunk with a unique chunk_id

    Args:
        section_text: raw section text
        section_type: section label from section detector
        note_id: source note identifier
        config: ChunkConfig with max_tokens and overlap_tokens
        tokenizer: GatorTron tokenizer for token counting

    Returns:
        list of Chunk objects (one if short enough, multiple if windowed)
    """
    # TODO: implement sliding window chunking
    raise NotImplementedError


def process_note_sections(
    sections: list[dict],
    note_id: str,
    config: ChunkConfig,
    tokenizer: AutoTokenizer,
) -> list[Chunk]:
    """
    Process all sections from a single note. Skip sections in config.skip_sections.
    Apply chunk_section to each retained section.

    Args:
        sections: list of dicts with keys "text" and "type" from section detector
        note_id: source note identifier
        config: ChunkConfig
        tokenizer: tokenizer for length checking

    Returns:
        list of Chunk objects ready for annotation
    """
    chunks = []
    for section in sections:
        if section["type"] in config.skip_sections:
            continue
        chunks.extend(
            chunk_section(
                section_text=section["text"],
                section_type=section["type"],
                note_id=note_id,
                config=config,
                tokenizer=tokenizer,
            )
        )
    return chunks
