"""
pipeline/train.py — Step 04: GatorTron Train / Retrain
-------------------------------------------------------
Fine-tunes GatorTron on accumulated labeled data. Initial run trains on
300 MIMIC gold examples. Subsequent runs train from the previous checkpoint
on the cumulative labeled set (MIMIC gold + filtered/corrected VA labels).

Per-class F1 is logged to MLflow every iteration.

Copilot: implement all TODO blocks.
"""

from __future__ import annotations
import logging
from pathlib import Path
import mlflow
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForTokenClassification,
    TrainingArguments,
    Trainer,
    DataCollatorForTokenClassification,
)
from datasets import Dataset
import numpy as np
from seqeval.metrics import classification_report, f1_score

from models import AnnotatedChunk, MimicGoldExample, Entity
from config import ModelConfig, PathConfig

logger = logging.getLogger(__name__)


def build_training_dataset(
    mimic_gold: list[MimicGoldExample],
    va_annotated: list[AnnotatedChunk],
    tokenizer: AutoTokenizer,
    label2id: dict[str, int],
) -> Dataset:
    """
    Build a HuggingFace Dataset from MIMIC gold examples and accumulated
    VA labeled chunks. Converts entity spans to BIO token labels.

    For VA chunks: use filtered_entities (post-filter final labels).
    For MIMIC gold: use entities directly.

    Args:
        mimic_gold: list of MimicGoldExample objects (all 300)
        va_annotated: AnnotatedChunk objects with filtered_entities set
        tokenizer: GatorTron tokenizer
        label2id: BIO label to integer mapping

    Returns:
        HuggingFace Dataset with input_ids, attention_mask, labels columns
    """
    # TODO: implement
    # 1. Convert each example/chunk to tokenized input with BIO labels
    # 2. Handle subword tokenization: assign label to first subword, -100 to rest
    # 3. Build Dataset from list of dicts
    raise NotImplementedError


def span_to_bio_labels(
    text: str,
    entities: list[Entity],
    tokenizer: AutoTokenizer,
    label2id: dict[str, int],
) -> dict:
    """
    Convert character-level entity spans to BIO token labels for a single text.

    Args:
        text: raw chunk text
        entities: entity predictions (filtered_entities)
        tokenizer: GatorTron tokenizer
        label2id: BIO label to integer id

    Returns:
        dict with input_ids, attention_mask, labels (aligned to tokens)
    """
    # TODO: implement
    # Use tokenizer(text, return_offsets_mapping=True) to align character spans
    # to token positions. First subword of a span gets B- label, subsequent
    # subwords get I- label, non-span tokens get O label.
    # Set special token labels to -100 (ignored by loss).
    raise NotImplementedError


def compute_seqeval_metrics(eval_pred, id2label: dict[int, str]) -> dict:
    """
    Compute per-class and overall F1 using seqeval.

    Args:
        eval_pred: (logits, labels) tuple from HuggingFace Trainer
        id2label: integer id to BIO label string

    Returns:
        dict with overall_f1 and per-class F1 values
    """
    # TODO: implement
    # 1. Argmax logits to get predicted token label ids
    # 2. Filter out -100 label positions
    # 3. Convert ids to label strings
    # 4. Run seqeval classification_report
    # 5. Return flat dict suitable for mlflow.log_metrics
    raise NotImplementedError


def train_or_retrain(
    mimic_gold: list[MimicGoldExample],
    va_annotated: list[AnnotatedChunk],
    model_config: ModelConfig,
    path_config: PathConfig,
    al_iteration: int,
    mimic_held_out: list[MimicGoldExample],
    from_checkpoint: bool = False,
) -> AutoModelForTokenClassification:
    """
    Fine-tune or retrain GatorTron.

    Initial run (al_iteration=0, from_checkpoint=False):
        Load from model_config.gator_model_id (HuggingFace hub)
        Train on MIMIC gold only

    Subsequent runs (al_iteration > 0, from_checkpoint=True):
        Load from latest checkpoint in path_config.model_checkpoint_dir
        Train on MIMIC gold + all accumulated VA labels

    Logs per-class F1 to MLflow under the "al_pipeline" experiment,
    tagged with al_iteration.

    Args:
        mimic_gold: all 300 MIMIC gold examples
        va_annotated: all accumulated AnnotatedChunk objects with labels
        model_config: ModelConfig
        path_config: PathConfig
        al_iteration: current AL iteration number (0 = initial seed)
        mimic_held_out: fixed held-out MIMIC slice for evaluation
        from_checkpoint: whether to load from previous checkpoint

    Returns:
        trained model
    """
    # TODO: implement full train/retrain logic with MLflow logging
    raise NotImplementedError
