"""
models.py
---------
Shared dataclasses for the entire pipeline. Every module imports from here.
Copilot: do not modify field names — they are referenced across all pipeline
modules. Add new fields at the end of each dataclass.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Entity:
    """A single predicted named entity span."""
    text: str
    label: str                          # e.g. "PROCEDURE_TREATMENT"
    start: int                          # character offset in chunk text
    end: int                            # character offset in chunk text
    confidence: float = 1.0            # span-level confidence from logprobs
    filtered: bool = False             # True if excluded by structured data filter
    filter_reason: Optional[str] = None  # "rxnorm" | "unit_pattern" | "gazetteer:{term}" | "classifier"


@dataclass
class Chunk:
    """A single text chunk from a VA clinical note section."""
    text: str
    section_type: str                  # e.g. "assessment_and_plan", "hpi"
    note_id: str
    chunk_id: str                      # f"{note_id}_{section_type}_{index}"
    token_count: int = 0


@dataclass
class DisagreementRecord:
    """
    Tracks disagreement history for a single predicted entity span across
    AL iterations. Spans with iteration_count >= persistent_threshold are
    flagged for final human review.
    """
    chunk_id: str
    span_text: str
    span_start: int
    span_end: int
    gpt_v1_label: str
    gpt_v2_label: str
    gator_label: str
    rxnorm_result: Optional[str]       # RxNorm concept name if linked, else None
    gazetteer_result: Optional[str]    # VA lab term match if found, else None
    iteration_count: int = 1
    resolved: bool = False
    resolved_label: Optional[str] = None
    flagged_for_human_review: bool = False


@dataclass
class AnnotatedChunk:
    """
    A chunk that has been through GPT-5.1 annotation and the per-entity filter.
    Carries dual predictions, GatorTron predictions, and all scoring signals.
    """
    chunk: Chunk
    gpt_v1_entities: list[Entity] = field(default_factory=list)
    gpt_v2_entities: list[Entity] = field(default_factory=list)
    gator_entities: list[Entity] = field(default_factory=list)
    filtered_entities: list[Entity] = field(default_factory=list)  # post-filter final labels
    uncertainty_score: float = 0.0
    query_score: float = 0.0
    al_iteration: int = 0
    disagreement_records: list[DisagreementRecord] = field(default_factory=list)
    corrective_annotation_applied: bool = False
    human_reviewed: bool = False
    gold_entities: list[Entity] = field(default_factory=list)  # set after human review


@dataclass
class MimicGoldExample:
    """A single hand-labeled MIMIC example used for few-shot retrieval."""
    text: str
    entities: list[Entity]
    example_id: str
    section_type: Optional[str] = None
    embedding: Optional[list[float]] = None  # set after embedding pass
