"""
pipeline/retrieval.py — FAISS Index Management + Few-Shot Retrieval
--------------------------------------------------------------------
Manages the FAISS index of MIMIC gold examples (and accumulated reviewed
VA examples). Provides dynamic few-shot retrieval at annotation time.

The index is initialized from 300 MIMIC gold examples and enriched with
human-reviewed VA spans after the final human review pass.

Copilot: implement all TODO blocks.
"""

from __future__ import annotations
import json
import faiss
import numpy as np
from pathlib import Path
from sentence_transformers import SentenceTransformer

from models import MimicGoldExample
from config import PathConfig


def load_embedder(model_id: str = "microsoft/BiomedNLP-BiomedBERT-large") -> SentenceTransformer:
    """Load and return the SentenceTransformer embedder. Cache at module level."""
    # TODO: implement with module-level cache
    raise NotImplementedError


def build_faiss_index(
    examples: list[MimicGoldExample],
    embedder: SentenceTransformer,
    index_path: Path,
    metadata_path: Path,
) -> tuple[faiss.Index, list[MimicGoldExample]]:
    """
    Embed all examples and build a FAISS IndexFlatIP (inner product / cosine
    similarity after L2 normalization). Save index and metadata to disk.

    Args:
        examples: list of MimicGoldExample objects
        embedder: SentenceTransformer model
        index_path: where to save the .index file
        metadata_path: where to save example metadata as JSONL

    Returns:
        (faiss_index, examples_with_embeddings)
    """
    # TODO: implement
    # 1. Encode all example texts in batch
    # 2. L2-normalize embeddings for cosine similarity via inner product
    # 3. Build IndexFlatIP, add embeddings
    # 4. Save index with faiss.write_index
    # 5. Save example metadata as JSONL
    raise NotImplementedError


def load_faiss_index(
    index_path: Path,
    metadata_path: Path,
) -> tuple[faiss.Index, list[MimicGoldExample]]:
    """
    Load FAISS index and metadata from disk.

    Returns:
        (faiss_index, gold_examples)
    """
    # TODO: implement
    raise NotImplementedError


def retrieve_few_shot_examples(
    query_text: str,
    faiss_index: faiss.Index,
    gold_examples: list[MimicGoldExample],
    embedder: SentenceTransformer,
    k: int = 5,
) -> list[MimicGoldExample]:
    """
    Retrieve top-k most similar gold examples for a query chunk.

    Args:
        query_text: the note chunk text being annotated
        faiss_index: loaded FAISS index
        gold_examples: ordered list matching FAISS index positions
        embedder: SentenceTransformer model
        k: number of examples to retrieve

    Returns:
        top-k MimicGoldExample objects ordered by similarity (descending)
    """
    # TODO: implement
    # 1. Encode query_text
    # 2. L2-normalize
    # 3. faiss_index.search(query_emb, k)
    # 4. Return gold_examples at returned indices
    raise NotImplementedError


def add_reviewed_examples_to_index(
    reviewed_chunks: list,
    faiss_index: faiss.Index,
    gold_examples: list[MimicGoldExample],
    embedder: SentenceTransformer,
    index_path: Path,
    metadata_path: Path,
) -> tuple[faiss.Index, list[MimicGoldExample]]:
    """
    Add human-reviewed VA spans to the FAISS index after final review pass.
    This shifts few-shot retrieval from MIMIC patterns toward VA population
    patterns for future pipeline runs.

    Args:
        reviewed_chunks: AnnotatedChunk objects with gold_entities set
        faiss_index: current FAISS index
        gold_examples: current gold example list
        embedder: SentenceTransformer model
        index_path: index save path
        metadata_path: metadata save path

    Returns:
        (updated_index, updated_gold_examples)
    """
    # TODO: implement
    # 1. Convert reviewed chunks to MimicGoldExample objects
    # 2. Embed their texts
    # 3. L2-normalize and add to index
    # 4. Extend gold_examples list
    # 5. Save updated index and metadata
    raise NotImplementedError
