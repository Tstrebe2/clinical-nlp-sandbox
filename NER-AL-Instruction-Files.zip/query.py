"""
pipeline/query.py — Step 06: AL Query Strategy
-----------------------------------------------
Joint query score combining GatorTron uncertainty with cross-model
and inter-prompt disagreement signals. PROCEDURE_TREATMENT predictions
are overweighted to direct the human review budget toward the known
problem class.

Score formula:
    score = class_weight * (
        alpha * uncertainty +
        (1 - alpha) * (0.6 * model_disagree + 0.4 * prompt_disagree)
    )

Copilot: implement all TODO blocks.
"""

from __future__ import annotations
import numpy as np
from models import AnnotatedChunk, Entity
from config import ALConfig


def compute_model_disagreement(
    gator_entities: list[Entity],
    gpt_v1_entities: list[Entity],
) -> float:
    """
    Compute cross-model disagreement between GatorTron and GPT-5.1 variant 1.
    Disagreement is measured at the span level: for each predicted span,
    check if the two models agree on label and boundaries.

    Returns:
        float in [0, 1] — fraction of spans with disagreement
        Returns 1.0 if one model predicts entities and the other predicts none.
    """
    # TODO: implement span-level disagreement
    # Handle edge cases: both predict empty (0.0), one empty one not (1.0)
    # For overlapping spans: compare labels; for non-overlapping: count as disagree
    raise NotImplementedError


def compute_prompt_disagreement(
    gpt_v1_entities: list[Entity],
    gpt_v2_entities: list[Entity],
) -> float:
    """
    Compute inter-prompt disagreement between GPT-5.1 variant 1 and variant 2.
    Same logic as compute_model_disagreement.

    Returns:
        float in [0, 1]
    """
    # TODO: implement — same logic as compute_model_disagreement
    raise NotImplementedError


def has_proc_treat_prediction(entities: list[Entity]) -> bool:
    """
    Return True if any entity in the list is labeled PROCEDURE_TREATMENT.
    Used for class overweighting.
    """
    return any(e.label == "PROCEDURE_TREATMENT" for e in entities)


def compute_query_score(
    annotated_chunk: AnnotatedChunk,
    config: ALConfig,
) -> float:
    """
    Compute the joint AL query score for a single annotated chunk.

    Inputs from annotated_chunk:
    - uncertainty_score: set by score.py (GatorTron token-level least confidence)
    - gpt_v1_entities, gpt_v2_entities: dual GPT predictions
    - gator_entities: GatorTron predictions on this chunk

    Args:
        annotated_chunk: AnnotatedChunk with uncertainty_score and entity predictions
        config: ALConfig with alpha, class_weight, disagree sub-weights

    Returns:
        float query score (higher = more informative to annotate)
    """
    uncertainty = annotated_chunk.uncertainty_score

    model_disagree = compute_model_disagreement(
        annotated_chunk.gator_entities,
        annotated_chunk.gpt_v1_entities,
    )

    prompt_disagree = compute_prompt_disagreement(
        annotated_chunk.gpt_v1_entities,
        annotated_chunk.gpt_v2_entities,
    )

    # PROCEDURE_TREATMENT overweighting
    all_preds = (
        annotated_chunk.gpt_v1_entities +
        annotated_chunk.gpt_v2_entities +
        annotated_chunk.gator_entities
    )
    class_weight = (
        config.proc_treat_class_weight
        if has_proc_treat_prediction(all_preds)
        else 1.0
    )

    score = class_weight * (
        config.uncertainty_alpha * uncertainty +
        (1 - config.uncertainty_alpha) * (
            config.model_disagree_weight * model_disagree +
            config.prompt_disagree_weight * prompt_disagree
        )
    )

    return float(score)


def select_query_batch(
    pool: list[AnnotatedChunk],
    config: ALConfig,
) -> list[AnnotatedChunk]:
    """
    Score all chunks in the unlabeled pool and select the top-k for
    corrective re-annotation.

    Args:
        pool: list of unlabeled AnnotatedChunk objects with uncertainty_score set
        config: ALConfig with al_batch_size and scoring parameters

    Returns:
        top-k AnnotatedChunk objects sorted by query score descending
    """
    for chunk in pool:
        chunk.query_score = compute_query_score(chunk, config)

    pool_sorted = sorted(pool, key=lambda c: c.query_score, reverse=True)
    return pool_sorted[: config.al_batch_size]
